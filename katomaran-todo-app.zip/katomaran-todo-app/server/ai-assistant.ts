import OpenAI from "openai";
import { InsertTask } from "../shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface VoiceTaskRequest {
  transcript: string;
  userEmail: string;
}

export interface AITaskSuggestion {
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  category?: string;
  dueDate?: string;
  moodRequired?: 'focused' | 'creative' | 'energetic' | 'calm';
  estimatedTime?: number;
}

export async function processVoiceCommand(request: VoiceTaskRequest): Promise<AITaskSuggestion> {
  try {
    const prompt = `
    You are a smart task management assistant. Analyze the following voice command and extract task information.
    
    Voice command: "${request.transcript}"
    
    Extract and suggest:
    - A clear, concise title
    - A helpful description
    - Priority level (low, medium, high)
    - Category if mentioned
    - Due date if mentioned (format as ISO string)
    - Required mood (focused, creative, energetic, calm) based on task type
    - Estimated time in minutes
    
    Return your response as JSON in this exact format:
    {
      "title": "string",
      "description": "string", 
      "priority": "low|medium|high",
      "category": "string or null",
      "dueDate": "ISO string or null",
      "moodRequired": "focused|creative|energetic|calm or null",
      "estimatedTime": "number or null"
    }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a helpful task management assistant. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      title: result.title || "New Task",
      description: result.description || "",
      priority: result.priority || "medium",
      category: result.category || undefined,
      dueDate: result.dueDate || undefined,
      moodRequired: result.moodRequired || undefined,
      estimatedTime: result.estimatedTime || undefined
    };
  } catch (error) {
    console.error("AI processing error:", error);
    
    // Smart fallback parsing without AI
    const transcript = request.transcript.toLowerCase();
    
    // Extract priority
    let priority: 'low' | 'medium' | 'high' = 'medium';
    if (transcript.includes('urgent') || transcript.includes('high priority') || transcript.includes('important')) {
      priority = 'high';
    } else if (transcript.includes('low priority') || transcript.includes('minor')) {
      priority = 'low';
    }
    
    // Extract mood
    let moodRequired: 'focused' | 'creative' | 'energetic' | 'calm' | undefined = undefined;
    if (transcript.includes('focus') || transcript.includes('concentrate')) {
      moodRequired = 'focused';
    } else if (transcript.includes('creative') || transcript.includes('design') || transcript.includes('brainstorm')) {
      moodRequired = 'creative';
    } else if (transcript.includes('exercise') || transcript.includes('active') || transcript.includes('energy')) {
      moodRequired = 'energetic';
    } else if (transcript.includes('relax') || transcript.includes('calm') || transcript.includes('meditate')) {
      moodRequired = 'calm';
    }
    
    // Extract due date
    let dueDate: string | undefined = undefined;
    if (transcript.includes('today')) {
      dueDate = new Date().toISOString();
    } else if (transcript.includes('tomorrow')) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      dueDate = tomorrow.toISOString();
    }
    
    // Extract title (first meaningful part)
    let title = request.transcript.slice(0, 60);
    if (transcript.includes('create') || transcript.includes('add') || transcript.includes('make')) {
      const words = request.transcript.split(' ');
      const taskStart = words.findIndex(word => 
        ['create', 'add', 'make', 'task', 'todo'].includes(word.toLowerCase())
      );
      if (taskStart >= 0 && taskStart < words.length - 1) {
        title = words.slice(taskStart + 1).join(' ').slice(0, 60);
      }
    }
    
    return {
      title: title || "Voice Task",
      description: `Task created from voice: ${request.transcript}`,
      priority,
      moodRequired,
      dueDate
    };
  }
}

export async function generateTaskSuggestions(userId: string, context: string): Promise<AITaskSuggestion[]> {
  try {
    const prompt = `
    Based on the following context, suggest 3 helpful tasks that would be productive:
    
    Context: ${context}
    
    Suggest tasks that are:
    - Actionable and specific
    - Varied in priority and type
    - Helpful for productivity
    
    Return as JSON array of tasks with the same structure as before.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a productivity assistant. Generate helpful task suggestions as JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.8
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.tasks || [];
  } catch (error) {
    console.error("Task suggestion error:", error);
    return [];
  }
}