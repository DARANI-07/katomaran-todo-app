import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage-minimal";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTaskSchema, updateTaskSchema, insertTaskShareSchema, insertHabitSchema, updateHabitSchema, insertHabitLogSchema } from "@shared/schema";
import { ZodError } from "zod";
import { processVoiceCommand, generateTaskSuggestions } from "./ai-assistant";
import { sendTaskCreatedNotification, sendDueDateReminder, formatDueDate } from "./email-service";
import { isToday, isTomorrow, parseISO, addDays } from "date-fns";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { status, priority, sortBy, sortOrder, page, limit } = req.query;
      
      const result = await storage.getTasks(userId, {
        status: status as string,
        priority: priority as string,
        sortBy: sortBy as string,
        sortOrder: sortOrder as 'asc' | 'desc',
        page: page ? parseInt(page as string) : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/shared', isAuthenticated, async (req: any, res) => {
    try {
      const userEmail = req.user.claims.email;
      if (!userEmail) {
        return res.status(400).json({ message: "User email not available" });
      }
      
      const sharedTasks = await storage.getSharedTasks(userEmail);
      res.json(sharedTasks);
    } catch (error) {
      console.error("Error fetching shared tasks:", error);
      res.status(500).json({ message: "Failed to fetch shared tasks" });
    }
  });

  app.get('/api/tasks/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getTaskStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching task stats:", error);
      res.status(500).json({ message: "Failed to fetch task stats" });
    }
  });

  app.get('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const task = await storage.getTask(taskId, userId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedTask = insertTaskSchema.parse(req.body);
      
      const task = await storage.createTask(validatedTask, userId);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.patch('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const validatedTask = updateTaskSchema.parse(req.body);
      const task = await storage.updateTask(taskId, validatedTask, userId);
      
      res.json(task);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      if (error instanceof Error && error.message === 'Task not found or unauthorized') {
        return res.status(404).json({ message: error.message });
      }
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      await storage.deleteTask(taskId, userId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Task sharing routes
  app.post('/api/tasks/:id/share', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      // Verify user owns the task
      const task = await storage.getTask(taskId, userId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const validatedShare = insertTaskShareSchema.parse(req.body);
      const share = await storage.shareTask(taskId, validatedShare.sharedWithEmail, userId);
      
      res.status(201).json(share);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error sharing task:", error);
      res.status(500).json({ message: "Failed to share task" });
    }
  });

  // Habit Routes
  app.get('/api/habits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const habits = await storage.getHabits(userId);
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ message: "Failed to fetch habits" });
    }
  });

  app.post('/api/habits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedHabit = insertHabitSchema.parse(req.body);
      
      const habit = await storage.createHabit(validatedHabit, userId);
      res.status(201).json(habit);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error creating habit:", error);
      res.status(500).json({ message: "Failed to create habit" });
    }
  });

  app.post('/api/habits/:id/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const habitId = parseInt(req.params.id);
      
      if (isNaN(habitId)) {
        return res.status(400).json({ message: "Invalid habit ID" });
      }

      const validatedLog = insertHabitLogSchema.parse({
        ...req.body,
        habitId
      });
      
      const habitLog = await storage.logHabitCompletion(habitId, validatedLog);
      res.status(201).json(habitLog);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error logging habit:", error);
      res.status(500).json({ message: "Failed to log habit" });
    }
  });

  // Voice Assistant Routes
  app.post('/api/voice/process', isAuthenticated, async (req: any, res) => {
    try {
      const { transcript, recipientEmail } = req.body;
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;

      if (!transcript) {
        return res.status(400).json({ message: "Transcript is required" });
      }

      // Process voice command with AI
      const aiSuggestion = await processVoiceCommand({
        transcript,
        userEmail
      });

      // Create task from AI suggestion
      const taskData = {
        title: aiSuggestion.title,
        description: aiSuggestion.description,
        priority: aiSuggestion.priority,
        category: aiSuggestion.category,
        dueDate: aiSuggestion.dueDate,
        moodRequired: aiSuggestion.moodRequired,
        estimatedTime: aiSuggestion.estimatedTime,
        status: 'not_started' as const
      };

      const validatedTask = insertTaskSchema.parse(taskData);
      const newTask = await storage.createTask(validatedTask, userId);

      // Always send email notification to task creator
      let emailSent = false;
      try {
        await sendTaskCreatedNotification(newTask, userEmail);
        emailSent = true;
      } catch (emailError) {
        console.error("Email notification failed:", emailError);
        // Don't fail the task creation if email fails
      }

      // Send additional email if recipient email provided
      if (recipientEmail && recipientEmail !== userEmail) {
        try {
          await sendTaskCreatedNotification(newTask, recipientEmail);
        } catch (emailError) {
          console.error("Additional email notification failed:", emailError);
        }
      }

      res.json({ 
        task: newTask, 
        aiSuggestion,
        emailSent: emailSent 
      });
    } catch (error) {
      console.error("Voice processing error:", error);
      res.status(500).json({ message: "Failed to process voice command" });
    }
  });

  // AI Task Suggestions
  app.post('/api/ai/suggest-tasks', isAuthenticated, async (req: any, res) => {
    try {
      const { context } = req.body;
      const userId = req.user.claims.sub;

      const suggestions = await generateTaskSuggestions(userId, context || "general productivity");
      res.json({ suggestions });
    } catch (error) {
      console.error("AI suggestion error:", error);
      res.status(500).json({ message: "Failed to generate suggestions" });
    }
  });

  // Email Notification Routes
  app.post('/api/notifications/task-created', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId, recipientEmail } = req.body;
      const userId = req.user.claims.sub;

      const task = await storage.getTask(taskId, userId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      const emailSent = await sendTaskCreatedNotification(task, recipientEmail);
      res.json({ success: emailSent });
    } catch (error) {
      console.error("Email notification error:", error);
      res.status(500).json({ message: "Failed to send notification" });
    }
  });

  app.post('/api/notifications/due-date-reminder', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId, recipientEmail } = req.body;
      const userId = req.user.claims.sub;

      const task = await storage.getTask(taskId, userId);
      if (!task || !task.dueDate) {
        return res.status(404).json({ message: "Task not found or no due date" });
      }

      const emailSent = await sendDueDateReminder(task, recipientEmail);
      res.json({ success: emailSent });
    } catch (error) {
      console.error("Due date reminder error:", error);
      res.status(500).json({ message: "Failed to send reminder" });
    }
  });

  // Check for due date alerts (automated)
  app.get('/api/alerts/due-dates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;

      // Get tasks that are due today or tomorrow
      const { tasks } = await storage.getTasks(userId, { limit: 100 });
      const alertTasks = tasks.filter(task => {
        if (!task.dueDate) return false;
        const dueDate = parseISO(task.dueDate);
        return isToday(dueDate) || isTomorrow(dueDate);
      });

      // Format alerts with natural language
      const alerts = alertTasks.map(task => ({
        id: task.id,
        title: task.title,
        dueDate: task.dueDate,
        dueDateText: formatDueDate(parseISO(task.dueDate!)),
        priority: task.priority,
        status: task.status,
        isUrgent: isToday(parseISO(task.dueDate!))
      }));

      res.json({ alerts });
    } catch (error) {
      console.error("Due date alerts error:", error);
      res.status(500).json({ message: "Failed to get due date alerts" });
    }
  });

  // Compatibility routes
  app.get('/auth/replit', (req, res) => {
    res.redirect('/api/login');
  });

  app.get('/auth/logout', (req, res) => {
    res.redirect('/api/logout');
  });

  const httpServer = createServer(app);
  return httpServer;
}
