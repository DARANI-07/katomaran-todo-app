import {
  users,
  tasks,
  taskShares,
  userPreferences,
  habits,
  habitLogs,
  taskAnalytics,
  taskSuggestions,
  notifications,
  type User,
  type UpsertUser,
  type Task,
  type InsertTask,
  type UpdateTask,
  type TaskShare,
  type InsertTaskShare,
  type UserPreferences,
  type InsertUserPreferences,
  type UpdateUserPreferences,
  type Habit,
  type InsertHabit,
  type UpdateHabit,
  type HabitLog,
  type InsertHabitLog,
  type TaskAnalytics,
  type InsertTaskAnalytics,
  type TaskSuggestion,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, count, sql, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User preferences operations
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  upsertUserPreferences(userId: string, preferences: InsertUserPreferences): Promise<UserPreferences>;
  
  // Task operations
  getTasks(userId: string, filters?: {
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
    category?: string;
    moodRequired?: string;
  }): Promise<{ tasks: Task[]; total: number }>;
  getTask(id: number, userId: string): Promise<Task | undefined>;
  createTask(task: InsertTask, userId: string): Promise<Task>;
  updateTask(id: number, task: UpdateTask, userId: string): Promise<Task>;
  deleteTask(id: number, userId: string): Promise<void>;
  
  // Task sharing operations
  shareTask(taskId: number, sharedWithEmail: string, sharedByUserId: string): Promise<TaskShare>;
  getSharedTasks(userEmail: string): Promise<Task[]>;
  
  // Task statistics
  getTaskStats(userId: string): Promise<{
    all: number;
    dueToday: number;
    overdue: number;
    completed: number;
    shared: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
    totalPoints: number;
    streakDays: number;
    level: number;
  }>;
  
  // Habit operations
  getHabits(userId: string): Promise<Habit[]>;
  getHabit(id: number, userId: string): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit, userId: string): Promise<Habit>;
  updateHabit(id: number, habit: UpdateHabit, userId: string): Promise<Habit>;
  deleteHabit(id: number, userId: string): Promise<void>;
  logHabitCompletion(habitId: number, log: InsertHabitLog): Promise<HabitLog>;
  
  // Analytics operations
  getTaskAnalytics(userId: string, startDate?: string, endDate?: string): Promise<TaskAnalytics[]>;
  createTaskAnalytics(analytics: InsertTaskAnalytics): Promise<TaskAnalytics>;
  
  // Task suggestions
  getTaskSuggestions(userId: string): Promise<TaskSuggestion[]>;
  generateTaskSuggestion(userId: string): Promise<TaskSuggestion>;
  acceptTaskSuggestion(suggestionId: number, userId: string): Promise<Task>;
  
  // Notifications
  getNotifications(userId: string, limit?: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(notificationId: number, userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User preferences operations
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [prefs] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return prefs;
  }

  async upsertUserPreferences(userId: string, preferences: InsertUserPreferences): Promise<UserPreferences> {
    const [prefs] = await db
      .insert(userPreferences)
      .values({ ...preferences, userId })
      .onConflictDoUpdate({
        target: userPreferences.userId,
        set: {
          ...preferences,
          updatedAt: new Date(),
        },
      })
      .returning();
    return prefs;
  }

  // Task operations
  async getTasks(userId: string, filters?: {
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
    category?: string;
    moodRequired?: string;
  }): Promise<{ tasks: Task[]; total: number }> {
    const page = filters?.page || 1;
    const limit = filters?.limit || 10;
    const offset = (page - 1) * limit;

    let whereConditions = [eq(tasks.userId, userId)];
    
    // Apply filters
    if (filters?.status && filters.status !== 'all') {
      whereConditions.push(eq(tasks.status, filters.status as any));
    }

    if (filters?.priority && filters.priority !== 'all') {
      whereConditions.push(eq(tasks.priority, filters.priority as any));
    }

    if (filters?.category && filters.category !== 'all') {
      whereConditions.push(eq(tasks.category, filters.category));
    }

    if (filters?.moodRequired && filters.moodRequired !== 'any') {
      whereConditions.push(eq(tasks.moodRequired, filters.moodRequired as any));
    }

    const whereClause = whereConditions.length > 1 ? and(...whereConditions) : whereConditions[0];

    // Build query with proper order by
    let query = db.select().from(tasks).where(whereClause);
    const countQuery = db.select({ count: count() }).from(tasks).where(whereClause);

    // Apply sorting
    const sortBy = filters?.sortBy || 'createdAt';
    const sortOrder = filters?.sortOrder || 'desc';
    
    if (sortBy === 'dueDate') {
      query = query.orderBy(sortOrder === 'asc' ? asc(tasks.dueDate) : desc(tasks.dueDate));
    } else if (sortBy === 'priority') {
      query = query.orderBy(sortOrder === 'asc' ? asc(tasks.priority) : desc(tasks.priority));
    } else if (sortBy === 'title') {
      query = query.orderBy(sortOrder === 'asc' ? asc(tasks.title) : desc(tasks.title));
    } else {
      query = query.orderBy(sortOrder === 'asc' ? asc(tasks.createdAt) : desc(tasks.createdAt));
    }

    // Apply pagination
    query = query.limit(limit).offset(offset);

    const [tasksResult, totalResult] = await Promise.all([
      query,
      countQuery
    ]);

    return {
      tasks: tasksResult,
      total: totalResult[0]?.count || 0
    };
  }

  async getTask(id: number, userId: string): Promise<Task | undefined> {
    const [task] = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
    return task;
  }

  async createTask(task: InsertTask, userId: string): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values({
        ...task,
        userId,
        completed: task.status === 'completed',
      })
      .returning();
    return newTask;
  }

  async updateTask(id: number, task: UpdateTask, userId: string): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({
        ...task,
        completed: task.status === 'completed',
        updatedAt: new Date(),
      })
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    
    if (!updatedTask) {
      throw new Error('Task not found or unauthorized');
    }
    
    return updatedTask;
  }

  async deleteTask(id: number, userId: string): Promise<void> {
    await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
  }

  // Task sharing operations
  async shareTask(taskId: number, sharedWithEmail: string, sharedByUserId: string): Promise<TaskShare> {
    const [share] = await db
      .insert(taskShares)
      .values({
        taskId,
        sharedWithEmail,
        sharedByUserId,
      })
      .returning();
    return share;
  }

  async getSharedTasks(userEmail: string): Promise<Task[]> {
    const sharedTasks = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        dueDate: tasks.dueDate,
        priority: tasks.priority,
        status: tasks.status,
        completed: tasks.completed,
        userId: tasks.userId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
      })
      .from(tasks)
      .innerJoin(taskShares, eq(tasks.id, taskShares.taskId))
      .where(eq(taskShares.sharedWithEmail, userEmail));

    return sharedTasks;
  }

  // Task statistics
  async getTaskStats(userId: string): Promise<{
    all: number;
    dueToday: number;
    overdue: number;
    completed: number;
    shared: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    
    const [
      allTasks,
      dueTodayTasks,
      overdueTasks,
      completedTasks,
      sharedTasks,
      highPriorityTasks,
      mediumPriorityTasks,
      lowPriorityTasks,
    ] = await Promise.all([
      db.select({ count: count() }).from(tasks).where(eq(tasks.userId, userId)),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.dueDate, today))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), sql`${tasks.dueDate} < ${today}`, eq(tasks.completed, false))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.completed, true))),
      db.select({ count: count() }).from(taskShares).where(eq(taskShares.sharedByUserId, userId)),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'high'))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'medium'))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'low'))),
    ]);

    return {
      all: allTasks[0]?.count || 0,
      dueToday: dueTodayTasks[0]?.count || 0,
      overdue: overdueTasks[0]?.count || 0,
      completed: completedTasks[0]?.count || 0,
      shared: sharedTasks[0]?.count || 0,
      highPriority: highPriorityTasks[0]?.count || 0,
      mediumPriority: mediumPriorityTasks[0]?.count || 0,
      lowPriority: lowPriorityTasks[0]?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
