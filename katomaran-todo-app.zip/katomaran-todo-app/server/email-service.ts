import { MailService } from '@sendgrid/mail';
import { Task } from '../shared/schema';
import { formatDistanceToNow, isToday, isTomorrow, isYesterday, format } from 'date-fns';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

export interface EmailNotification {
  to: string;
  subject: string;
  htmlContent: string;
  textContent: string;
}

export function formatDueDate(dueDate: Date): string {
  if (isToday(dueDate)) {
    return "today";
  } else if (isTomorrow(dueDate)) {
    return "tomorrow";
  } else if (isYesterday(dueDate)) {
    return "yesterday";
  } else {
    const distance = formatDistanceToNow(dueDate, { addSuffix: true });
    return distance;
  }
}

export function generateTaskCreatedEmail(task: Task, recipientEmail: string): EmailNotification {
  const dueDateText = task.dueDate ? formatDueDate(new Date(task.dueDate)) : "no due date set";
  const priorityEmoji = task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢';
  
  const subject = `New Task Assigned: ${task.title}`;
  
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 10px 10px 0 0; color: white;">
        <h1 style="margin: 0; font-size: 24px;">📋 New Task Assigned</h1>
      </div>
      
      <div style="background: #f8f9fa; padding: 25px; border-radius: 0 0 10px 10px; border: 1px solid #e9ecef;">
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-top: 0; display: flex; align-items: center; gap: 10px;">
            ${priorityEmoji} ${task.title}
          </h2>
          
          <div style="margin: 15px 0;">
            <p style="color: #666; margin: 5px 0;"><strong>Description:</strong></p>
            <p style="color: #444; background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 0;">
              ${task.description || 'No description provided'}
            </p>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
            <div style="background: #e3f2fd; padding: 12px; border-radius: 6px;">
              <strong style="color: #1976d2;">📅 Due Date:</strong><br>
              <span style="color: #333; font-size: 16px;">${dueDateText}</span>
            </div>
            
            <div style="background: #f3e5f5; padding: 12px; border-radius: 6px;">
              <strong style="color: #7b1fa2;">⚡ Priority:</strong><br>
              <span style="color: #333; font-size: 16px; text-transform: capitalize;">${task.priority}</span>
            </div>
          </div>
          
          ${task.category ? `
            <div style="background: #e8f5e8; padding: 12px; border-radius: 6px; margin: 15px 0;">
              <strong style="color: #2e7d32;">🏷️ Category:</strong>
              <span style="color: #333; font-size: 16px; margin-left: 10px;">${task.category}</span>
            </div>
          ` : ''}
          
          ${task.moodRequired ? `
            <div style="background: #fff3e0; padding: 12px; border-radius: 6px; margin: 15px 0;">
              <strong style="color: #f57c00;">😊 Mood Required:</strong>
              <span style="color: #333; font-size: 16px; margin-left: 10px; text-transform: capitalize;">${task.moodRequired}</span>
            </div>
          ` : ''}
        </div>
        
        <div style="text-align: center; margin-top: 20px; padding: 15px; background: #e3f2fd; border-radius: 8px;">
          <p style="margin: 0; color: #1976d2;">
            <strong>💡 Tip:</strong> Use the TaskFlow app to track your progress and stay organized!
          </p>
        </div>
      </div>
    </div>
  `;
  
  const textContent = `
New Task Assigned: ${task.title}

Description: ${task.description || 'No description provided'}
Due Date: ${dueDateText}
Priority: ${task.priority}
${task.category ? `Category: ${task.category}` : ''}
${task.moodRequired ? `Mood Required: ${task.moodRequired}` : ''}

Use the TaskFlow app to track your progress and stay organized!
  `;

  return {
    to: recipientEmail,
    subject,
    htmlContent,
    textContent
  };
}

export function generateDueDateReminderEmail(task: Task, recipientEmail: string): EmailNotification {
  const dueDateText = formatDueDate(new Date(task.dueDate!));
  const isUrgent = isToday(new Date(task.dueDate!)) || isYesterday(new Date(task.dueDate!));
  const urgencyEmoji = isUrgent ? '🚨' : '⏰';
  
  const subject = `${urgencyEmoji} Task Due ${dueDateText}: ${task.title}`;
  
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background: ${isUrgent ? 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)' : 'linear-gradient(135deg, #ffa726 0%, #ff9800 100%)'}; padding: 20px; border-radius: 10px 10px 0 0; color: white;">
        <h1 style="margin: 0; font-size: 24px;">${urgencyEmoji} Task Due ${dueDateText}</h1>
      </div>
      
      <div style="background: #f8f9fa; padding: 25px; border-radius: 0 0 10px 10px; border: 1px solid #e9ecef;">
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h2 style="color: #333; margin-top: 0;">${task.title}</h2>
          
          <div style="background: ${isUrgent ? '#ffebee' : '#fff8e1'}; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid ${isUrgent ? '#f44336' : '#ff9800'};">
            <p style="margin: 0; color: #333; font-size: 16px;">
              <strong>${isUrgent ? '🚨 URGENT:' : '⏰ REMINDER:'}</strong> This task is due <strong>${dueDateText}</strong>
            </p>
          </div>
          
          <div style="margin: 15px 0;">
            <p style="color: #666; margin: 5px 0;"><strong>Description:</strong></p>
            <p style="color: #444; background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 0;">
              ${task.description || 'No description provided'}
            </p>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
            <div style="background: #f3e5f5; padding: 12px; border-radius: 6px;">
              <strong style="color: #7b1fa2;">⚡ Priority:</strong><br>
              <span style="color: #333; font-size: 16px; text-transform: capitalize;">${task.priority}</span>
            </div>
            
            <div style="background: #e8f5e8; padding: 12px; border-radius: 6px;">
              <strong style="color: #2e7d32;">📊 Status:</strong><br>
              <span style="color: #333; font-size: 16px; text-transform: capitalize;">${task.status}</span>
            </div>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; padding: 15px; background: ${isUrgent ? '#ffebee' : '#e3f2fd'}; border-radius: 8px;">
          <p style="margin: 0; color: ${isUrgent ? '#d32f2f' : '#1976d2'};">
            <strong>💪 Don't forget to complete this task ${dueDateText}!</strong>
          </p>
        </div>
      </div>
    </div>
  `;
  
  const textContent = `
Task Due ${dueDateText}: ${task.title}

${isUrgent ? '🚨 URGENT REMINDER' : '⏰ REMINDER'}: This task is due ${dueDateText}

Description: ${task.description || 'No description provided'}
Priority: ${task.priority}
Status: ${task.status}

Don't forget to complete this task ${dueDateText}!
  `;

  return {
    to: recipientEmail,
    subject,
    htmlContent,
    textContent
  };
}

export async function sendEmail(notification: EmailNotification): Promise<boolean> {
  try {
    await mailService.send({
      to: notification.to,
      from: 'noreply@taskflow.app', // You can customize this
      subject: notification.subject,
      text: notification.textContent,
      html: notification.htmlContent,
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendTaskCreatedNotification(task: Task, recipientEmail: string): Promise<boolean> {
  const notification = generateTaskCreatedEmail(task, recipientEmail);
  return await sendEmail(notification);
}

export async function sendDueDateReminder(task: Task, recipientEmail: string): Promise<boolean> {
  const notification = generateDueDateReminderEmail(task, recipientEmail);
  return await sendEmail(notification);
}