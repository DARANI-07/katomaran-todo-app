import {
  users,
  tasks,
  taskShares,
  habits,
  habitLogs,
  type User,
  type UpsertUser,
  type Task,
  type InsertTask,
  type UpdateTask,
  type TaskShare,
  type InsertTaskShare,
  type Habit,
  type InsertHabit,
  type UpdateHabit,
  type HabitLog,
  type InsertHabitLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, sql } from "drizzle-orm";

export interface IStorageMinimal {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Task operations
  getTasks(userId: string, filters?: {
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
  }): Promise<{ tasks: Task[]; total: number }>;
  getTask(id: number, userId: string): Promise<Task | undefined>;
  createTask(task: InsertTask, userId: string): Promise<Task>;
  updateTask(id: number, task: UpdateTask, userId: string): Promise<Task>;
  deleteTask(id: number, userId: string): Promise<void>;
  
  // Task sharing operations
  shareTask(taskId: number, sharedWithEmail: string, sharedByUserId: string): Promise<TaskShare>;
  getSharedTasks(userEmail: string): Promise<Task[]>;
  
  // Task statistics
  getTaskStats(userId: string): Promise<{
    all: number;
    dueToday: number;
    overdue: number;
    completed: number;
    shared: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
  }>;

  // Habit operations
  getHabits(userId: string): Promise<Habit[]>;
  createHabit(habit: InsertHabit, userId: string): Promise<Habit>;
  logHabitCompletion(habitId: number, log: InsertHabitLog): Promise<HabitLog>;
}

export class MinimalDatabaseStorage implements IStorageMinimal {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getTasks(userId: string, filters?: {
    status?: string;
    priority?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
  }): Promise<{ tasks: Task[]; total: number }> {
    const page = filters?.page || 1;
    const limit = filters?.limit || 10;
    const offset = (page - 1) * limit;

    // Base queries
    let baseQuery = db.select().from(tasks);
    let countQuery = db.select({ count: count() }).from(tasks);
    
    // Build where conditions
    let whereConditions = [eq(tasks.userId, userId)];
    
    if (filters?.status && filters.status !== 'all') {
      whereConditions.push(eq(tasks.status, filters.status as any));
    }

    if (filters?.priority && filters.priority !== 'all') {
      whereConditions.push(eq(tasks.priority, filters.priority as any));
    }

    const whereClause = whereConditions.length === 1 ? whereConditions[0] : and(...whereConditions);
    
    // Apply where clause
    baseQuery = baseQuery.where(whereClause);
    countQuery = countQuery.where(whereClause);

    // Apply sorting
    const sortBy = filters?.sortBy || 'createdAt';
    const sortOrder = filters?.sortOrder || 'desc';
    
    if (sortBy === 'dueDate') {
      baseQuery = baseQuery.orderBy(sortOrder === 'asc' ? asc(tasks.dueDate) : desc(tasks.dueDate));
    } else if (sortBy === 'priority') {
      baseQuery = baseQuery.orderBy(sortOrder === 'asc' ? asc(tasks.priority) : desc(tasks.priority));
    } else if (sortBy === 'title') {
      baseQuery = baseQuery.orderBy(sortOrder === 'asc' ? asc(tasks.title) : desc(tasks.title));
    } else {
      baseQuery = baseQuery.orderBy(sortOrder === 'asc' ? asc(tasks.createdAt) : desc(tasks.createdAt));
    }

    // Apply pagination
    baseQuery = baseQuery.limit(limit).offset(offset);

    const [tasksResult, totalResult] = await Promise.all([
      baseQuery,
      countQuery
    ]);

    return {
      tasks: tasksResult,
      total: totalResult[0]?.count || 0
    };
  }

  async getTask(id: number, userId: string): Promise<Task | undefined> {
    const [task] = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
    return task;
  }

  async createTask(task: InsertTask, userId: string): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values({
        ...task,
        userId,
        completed: task.status === 'completed',
      })
      .returning();
    return newTask;
  }

  async updateTask(id: number, task: UpdateTask, userId: string): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({
        ...task,
        completed: task.status === 'completed',
        updatedAt: new Date(),
      })
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    
    if (!updatedTask) {
      throw new Error('Task not found or unauthorized');
    }
    
    return updatedTask;
  }

  async deleteTask(id: number, userId: string): Promise<void> {
    await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
  }

  async shareTask(taskId: number, sharedWithEmail: string, sharedByUserId: string): Promise<TaskShare> {
    const [share] = await db
      .insert(taskShares)
      .values({
        taskId,
        sharedWithEmail,
        sharedByUserId,
      })
      .returning();
    return share;
  }

  async getSharedTasks(userEmail: string): Promise<Task[]> {
    const sharedTasks = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        dueDate: tasks.dueDate,
        priority: tasks.priority,
        status: tasks.status,
        completed: tasks.completed,
        userId: tasks.userId,
        category: tasks.category,
        tags: tasks.tags,
        estimatedTime: tasks.estimatedTime,
        actualTime: tasks.actualTime,
        reminderTime: tasks.reminderTime,
        isRecurring: tasks.isRecurring,
        recurringPattern: tasks.recurringPattern,
        moodRequired: tasks.moodRequired,
        gamificationPoints: tasks.gamificationPoints,
        difficulty: tasks.difficulty,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
      })
      .from(tasks)
      .innerJoin(taskShares, eq(tasks.id, taskShares.taskId))
      .where(eq(taskShares.sharedWithEmail, userEmail));

    return sharedTasks;
  }

  async getTaskStats(userId: string): Promise<{
    all: number;
    dueToday: number;
    overdue: number;
    completed: number;
    shared: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    
    const [
      allTasks,
      dueTodayTasks,
      overdueTasks,
      completedTasks,
      sharedTasks,
      highPriorityTasks,
      mediumPriorityTasks,
      lowPriorityTasks,
    ] = await Promise.all([
      db.select({ count: count() }).from(tasks).where(eq(tasks.userId, userId)),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.dueDate, today))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), sql`${tasks.dueDate} < ${today}`, eq(tasks.completed, false))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.completed, true))),
      db.select({ count: count() }).from(taskShares).where(eq(taskShares.sharedByUserId, userId)),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'high'))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'medium'))),
      db.select({ count: count() }).from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.priority, 'low'))),
    ]);

    return {
      all: allTasks[0]?.count || 0,
      dueToday: dueTodayTasks[0]?.count || 0,
      overdue: overdueTasks[0]?.count || 0,
      completed: completedTasks[0]?.count || 0,
      shared: sharedTasks[0]?.count || 0,
      highPriority: highPriorityTasks[0]?.count || 0,
      mediumPriority: mediumPriorityTasks[0]?.count || 0,
      lowPriority: lowPriorityTasks[0]?.count || 0,
    };
  }

  async getHabits(userId: string): Promise<Habit[]> {
    const userHabits = await db.select().from(habits).where(eq(habits.userId, userId));
    return userHabits;
  }

  async createHabit(habit: InsertHabit, userId: string): Promise<Habit> {
    const [newHabit] = await db.insert(habits).values({
      ...habit,
      userId,
    }).returning();
    
    return newHabit;
  }

  async logHabitCompletion(habitId: number, log: InsertHabitLog): Promise<HabitLog> {
    const [habitLog] = await db.insert(habitLogs).values(log).returning();
    return habitLog;
  }
}

export const storage = new MinimalDatabaseStorage();