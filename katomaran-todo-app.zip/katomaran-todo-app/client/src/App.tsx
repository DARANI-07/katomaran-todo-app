import { Router, Route, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ThemeProvider } from "./components/theme-provider";
import { Toaster } from "./components/ui/toaster";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { TaskDashboard } from "./components/TaskDashboard";
import { Loader2 } from "lucide-react";

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="taskflow-theme">
      <Router>
        <div className="min-h-screen bg-background">
          <Route path="/login" component={LoginPage} />
          <Route path="/" component={MainApp} />
        </div>
      </Router>
      <Toaster />
    </ThemeProvider>
  );
}

function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <Card className="w-[400px]">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl text-center">Welcome to TaskFlow</CardTitle>
          <CardDescription className="text-center">
            Sign in to access your task management dashboard
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="w-full"
          >
            Sign in with Replit
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function MainApp() {
  const { data: user, isLoading, error } = useQuery({
    queryKey: ['/api/auth/user'],
    retry: false, // Don't retry on auth errors
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // If we get an error (like 401) or no user, show login page
  if (error || !user) {
    return <LoginPage />;
  }

  const userData = user as any; // Type assertion for quick fix

  return (
    <div className="min-h-screen bg-background">
      <header className="gradient-bg shadow-lg border-b border-white/20">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="text-3xl">📋</div>
              <h1 className="text-3xl font-bold text-white bg-gradient-to-r from-white to-gray-100 bg-clip-text text-transparent">
                TaskFlow
              </h1>
              <div className="hidden md:flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                <div className="text-white/80 text-sm">✨ Productive • 🎯 Organized • 🚀 Efficient</div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-white/90 text-sm">Welcome, {userData.name || userData.email}!</div>
              <Button 
                variant="ghost" 
                className="text-white hover:bg-white/20 border border-white/30"
                onClick={() => window.location.href = '/api/logout'}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        <TaskDashboard />
      </main>
    </div>
  );
}



export default App;