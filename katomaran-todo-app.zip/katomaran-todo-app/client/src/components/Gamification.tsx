import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { useQuery } from '@tanstack/react-query';
import { Trophy, Star, Target, Zap, Medal, Gift } from 'lucide-react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  points: number;
  unlocked: boolean;
  progress?: number;
  target?: number;
}

interface GamificationData {
  totalPoints: number;
  level: number;
  streakDays: number;
  pointsToNextLevel: number;
  achievements: Achievement[];
  weeklyGoal: number;
  weeklyProgress: number;
}

export function Gamification() {
  const [showConfetti, setShowConfetti] = useState(false);
  const [recentAchievement, setRecentAchievement] = useState<Achievement | null>(null);

  const { data: stats } = useQuery({
    queryKey: ['/api/tasks/stats'],
  });

  const { data: tasks } = useQuery({
    queryKey: ['/api/tasks'],
  });

  // Calculate gamification data
  const gamificationData: GamificationData = {
    totalPoints: (stats as any)?.totalPoints || 0,
    level: Math.floor(((stats as any)?.totalPoints || 0) / 100) + 1,
    streakDays: (stats as any)?.streakDays || 0,
    pointsToNextLevel: 100 - (((stats as any)?.totalPoints || 0) % 100),
    weeklyGoal: 7, // 7 tasks per week
    weeklyProgress: (stats as any)?.completed || 0,
    achievements: [
      {
        id: 'first_task',
        title: 'Getting Started',
        description: 'Complete your first task',
        icon: '🎯',
        points: 10,
        unlocked: (stats as any)?.completed > 0,
      },
      {
        id: 'streak_3',
        title: 'Consistent Worker',
        description: 'Complete tasks for 3 days straight',
        icon: '🔥',
        points: 25,
        unlocked: (stats as any)?.streakDays >= 3,
        progress: Math.min((stats as any)?.streakDays || 0, 3),
        target: 3,
      },
      {
        id: 'high_priority_master',
        title: 'Priority Master',
        description: 'Complete 5 high priority tasks',
        icon: '⚡',
        points: 30,
        unlocked: (stats as any)?.highPriority >= 5,
        progress: Math.min((stats as any)?.highPriority || 0, 5),
        target: 5,
      },
      {
        id: 'productivity_guru',
        title: 'Productivity Guru',
        description: 'Complete 20 tasks total',
        icon: '🏆',
        points: 50,
        unlocked: (stats as any)?.completed >= 20,
        progress: Math.min((stats as any)?.completed || 0, 20),
        target: 20,
      },
      {
        id: 'voice_commander',
        title: 'Voice Commander',
        description: 'Create 5 tasks using voice commands',
        icon: '🎤',
        points: 40,
        unlocked: false, // This would need tracking in backend
        progress: 0,
        target: 5,
      },
      {
        id: 'mood_master',
        title: 'Mood Master',
        description: 'Complete tasks in all 4 mood categories',
        icon: '😊',
        points: 35,
        unlocked: false, // This would need tracking in backend
        progress: 2,
        target: 4,
      },
    ],
  };

  const getPointsForTask = (priority: string): number => {
    switch (priority) {
      case 'high': return 15;
      case 'medium': return 10;
      case 'low': return 5;
      default: return 5;
    }
  };

  const getLevelTitle = (level: number): string => {
    if (level < 5) return 'Beginner';
    if (level < 10) return 'Productive';
    if (level < 20) return 'Expert';
    if (level < 50) return 'Master';
    return 'Legendary';
  };

  const triggerAchievementUnlock = (achievement: Achievement) => {
    setRecentAchievement(achievement);
    setShowConfetti(true);
    setTimeout(() => {
      setShowConfetti(false);
      setRecentAchievement(null);
    }, 3000);
  };

  useEffect(() => {
    // Check for newly unlocked achievements
    const newlyUnlocked = gamificationData.achievements.find(
      (achievement) => achievement.unlocked && achievement.id === 'first_task'
    );
    if (newlyUnlocked && !recentAchievement) {
      triggerAchievementUnlock(newlyUnlocked);
    }
  }, [stats]);

  return (
    <div className="space-y-6">
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 opacity-20 animate-pulse"></div>
        </div>
      )}

      {/* Recent Achievement Popup */}
      {recentAchievement && (
        <Card className="border-yellow-400 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 animate-bounce">
          <CardHeader className="text-center">
            <div className="text-4xl mb-2">{recentAchievement.icon}</div>
            <CardTitle className="text-yellow-800 dark:text-yellow-200">
              Achievement Unlocked!
            </CardTitle>
            <CardDescription className="text-yellow-700 dark:text-yellow-300">
              {recentAchievement.title} - {recentAchievement.description}
            </CardDescription>
            <Badge className="mx-auto w-fit bg-yellow-500 text-white">
              +{recentAchievement.points} points
            </Badge>
          </CardHeader>
        </Card>
      )}

      {/* Player Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="gradient-card card-hover">
          <CardHeader className="text-center pb-2">
            <div className="text-2xl">⭐</div>
            <CardTitle className="text-lg">Level {gamificationData.level}</CardTitle>
            <CardDescription>{getLevelTitle(gamificationData.level)}</CardDescription>
          </CardHeader>
          <CardContent>
            <Progress 
              value={(100 - gamificationData.pointsToNextLevel)} 
              className="h-2"
            />
            <p className="text-xs text-center mt-2 text-muted-foreground">
              {gamificationData.pointsToNextLevel} points to next level
            </p>
          </CardContent>
        </Card>

        <Card className="gradient-card card-hover">
          <CardHeader className="text-center pb-2">
            <div className="text-2xl">🏆</div>
            <CardTitle className="text-lg">{gamificationData.totalPoints}</CardTitle>
            <CardDescription>Total Points</CardDescription>
          </CardHeader>
        </Card>

        <Card className="gradient-card card-hover">
          <CardHeader className="text-center pb-2">
            <div className="text-2xl">🔥</div>
            <CardTitle className="text-lg">{gamificationData.streakDays}</CardTitle>
            <CardDescription>Day Streak</CardDescription>
          </CardHeader>
        </Card>

        <Card className="gradient-card card-hover">
          <CardHeader className="text-center pb-2">
            <div className="text-2xl">🎯</div>
            <CardTitle className="text-lg">{gamificationData.weeklyProgress}/{gamificationData.weeklyGoal}</CardTitle>
            <CardDescription>Weekly Goal</CardDescription>
          </CardHeader>
          <CardContent>
            <Progress 
              value={(gamificationData.weeklyProgress / gamificationData.weeklyGoal) * 100} 
              className="h-2"
            />
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Achievements
          </CardTitle>
          <CardDescription>
            Unlock achievements by completing tasks and maintaining productivity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gamificationData.achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border transition-all duration-300 ${
                  achievement.unlocked
                    ? 'bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800'
                    : 'bg-muted/50 border-muted-foreground/20 opacity-60'
                }`}
              >
                <div className="text-center space-y-2">
                  <div className={`text-3xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                    {achievement.icon}
                  </div>
                  <h3 className="font-semibold">{achievement.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {achievement.description}
                  </p>
                  
                  {achievement.target && (
                    <div className="space-y-1">
                      <Progress 
                        value={(achievement.progress! / achievement.target) * 100} 
                        className="h-1"
                      />
                      <p className="text-xs text-muted-foreground">
                        {achievement.progress}/{achievement.target}
                      </p>
                    </div>
                  )}
                  
                  <Badge 
                    variant={achievement.unlocked ? "default" : "secondary"}
                    className={achievement.unlocked ? "bg-green-500 text-white" : ""}
                  >
                    {achievement.unlocked ? "Unlocked" : `${achievement.points} points`}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Point Values Guide */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Point System
          </CardTitle>
          <CardDescription>
            Earn points by completing tasks based on their priority
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
              <div className="text-lg font-bold text-red-600 dark:text-red-400">15 pts</div>
              <div className="text-sm text-red-700 dark:text-red-300">High Priority</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800">
              <div className="text-lg font-bold text-yellow-600 dark:text-yellow-400">10 pts</div>
              <div className="text-sm text-yellow-700 dark:text-yellow-300">Medium Priority</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
              <div className="text-lg font-bold text-green-600 dark:text-green-400">5 pts</div>
              <div className="text-sm text-green-700 dark:text-green-300">Low Priority</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}