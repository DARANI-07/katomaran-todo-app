// Simple toaster component for now
export function Toaster() {
  return null;
}