import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { Plus, Flame, Target, TrendingUp, Calendar } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "./ui/dialog";

export function HabitTracker() {
  const [showCreateHabit, setShowCreateHabit] = useState(false);
  const [newHabit, setNewHabit] = useState({
    name: "",
    description: "",
    frequency: "daily",
    category: "health",
    targetStreak: 30
  });

  const queryClient = useQueryClient();

  const { data: habits } = useQuery({
    queryKey: ['/api/habits'],
  });

  const createHabitMutation = useMutation({
    mutationFn: (habit: any) =>
      fetch('/api/habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(habit),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      setShowCreateHabit(false);
      setNewHabit({
        name: "",
        description: "",
        frequency: "daily",
        category: "health",
        targetStreak: 30
      });
    },
  });

  const logHabitMutation = useMutation({
    mutationFn: ({ habitId, completed }: { habitId: number; completed: boolean }) =>
      fetch(`/api/habits/${habitId}/log`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ 
          completed, 
          date: new Date().toISOString().split('T')[0] 
        }),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
    },
  });

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    createHabitMutation.mutate(newHabit);
  };

  const handleToggleHabit = (habitId: number, completed: boolean) => {
    logHabitMutation.mutate({ habitId, completed: !completed });
  };

  const habitsData = habits as any;

  const getStreakColor = (streak: number, target: number) => {
    if (streak >= target) return "text-green-600";
    if (streak >= target * 0.7) return "text-yellow-600";
    return "text-red-600";
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'health': return '🏃‍♂️';
      case 'learning': return '📚';
      case 'productivity': return '⚡';
      case 'mindfulness': return '🧘‍♀️';
      case 'social': return '👥';
      default: return '🎯';
    }
  };

  // Generate last 7 days for habit tracking grid
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    last7Days.push(date.toISOString().split('T')[0]);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Habit Tracker</h2>
          <p className="text-muted-foreground">Build lasting habits with consistent tracking</p>
        </div>
        <Dialog open={showCreateHabit} onOpenChange={setShowCreateHabit}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Habit
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Habit</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateHabit} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Habit Name</label>
                <input
                  type="text"
                  value={newHabit.name}
                  onChange={(e) => setNewHabit({ ...newHabit, name: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="e.g., Drink 8 glasses of water"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Description</label>
                <textarea
                  value={newHabit.description}
                  onChange={(e) => setNewHabit({ ...newHabit, description: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Why is this habit important to you?"
                  rows={2}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Frequency</label>
                  <select
                    value={newHabit.frequency}
                    onChange={(e) => setNewHabit({ ...newHabit, frequency: e.target.value })}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Category</label>
                  <select
                    value={newHabit.category}
                    onChange={(e) => setNewHabit({ ...newHabit, category: e.target.value })}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="health">Health</option>
                    <option value="learning">Learning</option>
                    <option value="productivity">Productivity</option>
                    <option value="mindfulness">Mindfulness</option>
                    <option value="social">Social</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Target Streak (days)</label>
                <input
                  type="number"
                  value={newHabit.targetStreak}
                  onChange={(e) => setNewHabit({ ...newHabit, targetStreak: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  min="1"
                  max="365"
                />
              </div>
              <Button type="submit" className="w-full">Create Habit</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {habitsData?.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Target className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No habits yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Start building positive habits to improve your daily routine
            </p>
            <Button onClick={() => setShowCreateHabit(true)}>
              Create Your First Habit
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {habitsData?.map((habit: any) => (
            <Card key={habit.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{getCategoryIcon(habit.category)}</span>
                    <div>
                      <CardTitle className="text-lg">{habit.name}</CardTitle>
                      <CardDescription>{habit.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{habit.frequency}</Badge>
                    <div className="flex items-center gap-1">
                      <Flame className={`h-4 w-4 ${getStreakColor(habit.currentStreak || 0, habit.targetStreak)}`} />
                      <span className={`font-bold ${getStreakColor(habit.currentStreak || 0, habit.targetStreak)}`}>
                        {habit.currentStreak || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      Target: {habit.targetStreak} days
                    </span>
                    <div className="w-48 bg-secondary rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all" 
                        style={{ width: `${Math.min((habit.currentStreak || 0) / habit.targetStreak * 100, 100)}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium">
                      {Math.round(Math.min((habit.currentStreak || 0) / habit.targetStreak * 100, 100))}%
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Last 7 Days</span>
                      <span className="text-xs text-muted-foreground">
                        {last7Days[0]} - {last7Days[6]}
                      </span>
                    </div>
                    <div className="grid grid-cols-7 gap-1">
                      {last7Days.map((date, index) => {
                        const isCompleted = habit.logs?.some((log: any) => 
                          log.date === date && log.completed
                        );
                        const isToday = date === new Date().toISOString().split('T')[0];
                        
                        return (
                          <div key={date} className="text-center">
                            <div className="text-xs text-muted-foreground mb-1">
                              {new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}
                            </div>
                            <button
                              onClick={() => {
                                if (isToday) {
                                  handleToggleHabit(habit.id, isCompleted);
                                }
                              }}
                              disabled={!isToday}
                              className={`w-8 h-8 rounded-full border-2 transition-colors ${
                                isCompleted 
                                  ? 'bg-green-500 border-green-500' 
                                  : isToday 
                                    ? 'border-primary hover:bg-primary/10 cursor-pointer' 
                                    : 'border-muted cursor-not-allowed'
                              }`}
                            >
                              {isCompleted && (
                                <div className="w-full h-full flex items-center justify-center">
                                  <div className="w-2 h-2 bg-white rounded-full"></div>
                                </div>
                              )}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {new Date().toISOString().split('T')[0] === last7Days[6] && (
                    <div className="flex items-center gap-2 pt-2 border-t">
                      <Checkbox
                        checked={habit.logs?.some((log: any) => 
                          log.date === new Date().toISOString().split('T')[0] && log.completed
                        )}
                        onCheckedChange={(checked) => 
                          handleToggleHabit(habit.id, !checked)
                        }
                      />
                      <span className="text-sm">Mark as completed for today</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )) || []}
        </div>
      )}
    </div>
  );
}