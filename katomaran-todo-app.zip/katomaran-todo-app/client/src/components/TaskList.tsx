import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { 
  Calendar, Clock, Share, Edit, Trash2, Play, Pause, CheckCircle, 
  Brain, Sparkles, Zap, Heart, Trophy, Star, Volume2 
} from "lucide-react";
import Confetti from 'react-confetti';

interface TaskListProps {
  tasks: any[];
  filter: string;
  voiceEnabled?: boolean;
}

export function TaskList({ tasks, filter, voiceEnabled }: TaskListProps) {
  const [showConfetti, setShowConfetti] = useState(false);
  const [completedTask, setCompletedTask] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: any }) =>
      fetch(`/api/tasks/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(updates),
      }).then(res => res.json()),
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/stats'] });
      
      // Trigger confetti for task completion
      if (variables.updates.completed) {
        setCompletedTask(data.title);
        setShowConfetti(true);
        
        // Speak completion message if voice is enabled
        if (voiceEnabled && 'speechSynthesis' in window) {
          const utterance = new SpeechSynthesisUtterance(
            `Great job! You completed "${data.title}". You earned points!`
          );
          speechSynthesis.speak(utterance);
        }
        
        setTimeout(() => {
          setShowConfetti(false);
          setCompletedTask(null);
        }, 3000);
      }
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (id: number) =>
      fetch(`/api/tasks/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/stats'] });
    },
  });

  const handleCompleteTask = (task: any) => {
    updateTaskMutation.mutate({
      id: task.id,
      updates: { 
        completed: !task.completed,
        status: task.completed ? 'not_started' : 'completed'
      }
    });
  };

  const handleStatusChange = (task: any, status: string) => {
    updateTaskMutation.mutate({
      id: task.id,
      updates: { status }
    });
  };

  const getMoodIcon = (mood: string) => {
    switch (mood) {
      case 'focused': return <Brain className="h-4 w-4 text-blue-500" />;
      case 'creative': return <Sparkles className="h-4 w-4 text-purple-500" />;
      case 'energetic': return <Zap className="h-4 w-4 text-yellow-500" />;
      case 'calm': return <Heart className="h-4 w-4 text-green-500" />;
      default: return <Brain className="h-4 w-4 text-blue-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950';
      case 'medium': return 'border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950';
      case 'low': return 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950';
      default: return '';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in_progress': return <Play className="h-4 w-4 text-blue-500" />;
      default: return <Pause className="h-4 w-4 text-gray-400" />;
    }
  };

  const isOverdue = (dueDate: string) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date() && !tasks.find(t => t.dueDate === dueDate)?.completed;
  };

  const speakTask = (task: any) => {
    if ('speechSynthesis' in window) {
      const text = `Task: ${task.title}. ${task.description || ''}. Priority: ${task.priority}. ${task.dueDate ? `Due: ${task.dueDate}` : ''}`;
      const utterance = new SpeechSynthesisUtterance(text);
      speechSynthesis.speak(utterance);
    }
  };

  if (!tasks || tasks.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Trophy className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No tasks found</h3>
          <p className="text-muted-foreground text-center">
            Create your first task to start managing your productivity!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      {showConfetti && (
        <Confetti
          width={window.innerWidth}
          height={window.innerHeight}
          recycle={false}
          numberOfPieces={200}
        />
      )}
      
      <div className="space-y-3">
        {tasks.map((task) => (
          <Card 
            key={task.id} 
            className={`transition-all hover:shadow-md ${getPriorityColor(task.priority)} ${
              task.completed ? 'opacity-75' : ''
            } ${isOverdue(task.dueDate) ? 'border-red-500 shadow-red-100' : ''}`}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Checkbox
                  checked={task.completed}
                  onCheckedChange={() => handleCompleteTask(task)}
                  className="mt-1"
                />
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className={`font-medium ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                      {task.title}
                    </h3>
                    {getMoodIcon(task.moodRequired)}
                    <Badge variant={task.priority === 'high' ? 'destructive' : 'secondary'}>
                      {task.priority}
                    </Badge>
                    {getStatusIcon(task.status)}
                  </div>
                  
                  {task.description && (
                    <p className={`text-sm text-muted-foreground mb-2 ${task.completed ? 'line-through' : ''}`}>
                      {task.description}
                    </p>
                  )}
                  
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    {task.dueDate && (
                      <div className={`flex items-center gap-1 ${isOverdue(task.dueDate) ? 'text-red-500 font-medium' : ''}`}>
                        <Calendar className="h-3 w-3" />
                        {new Date(task.dueDate).toLocaleDateString()}
                        {isOverdue(task.dueDate) && <span className="text-red-500 font-bold">OVERDUE</span>}
                      </div>
                    )}
                    {task.estimatedDuration && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {task.estimatedDuration}m
                      </div>
                    )}
                    {task.category && (
                      <Badge variant="outline" className="text-xs">
                        {task.category}
                      </Badge>
                    )}
                    {task.points && (
                      <div className="flex items-center gap-1 text-yellow-600">
                        <Star className="h-3 w-3" />
                        {task.points} pts
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-1">
                  {voiceEnabled && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => speakTask(task)}
                      className="h-8 w-8 p-0"
                    >
                      <Volume2 className="h-3 w-3" />
                    </Button>
                  )}
                  
                  {!task.completed && (
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleStatusChange(task, 
                          task.status === 'in_progress' ? 'not_started' : 'in_progress'
                        )}
                        className="h-8 w-8 p-0"
                      >
                        {task.status === 'in_progress' ? (
                          <Pause className="h-3 w-3" />
                        ) : (
                          <Play className="h-3 w-3" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                      >
                        <Share className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTaskMutation.mutate(task.id)}
                    className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              
              {completedTask === task.title && (
                <div className="mt-2 p-2 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                    <Trophy className="h-4 w-4" />
                    <span className="text-sm font-medium">Task completed! +10 points earned</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}