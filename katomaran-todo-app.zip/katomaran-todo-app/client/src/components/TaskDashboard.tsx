import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Filter, Calendar, BarChart3, Mic, MicOff } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { TaskList } from "./TaskList";
import { TaskForm } from "./TaskForm";
import { TaskAnalytics } from "./TaskAnalytics";
import { TaskCalendar } from "./TaskCalendar";
import { HabitTracker } from "./HabitTracker";
import { VoiceAssistant } from "./VoiceAssistant";
import { Gamification } from "./Gamification";
import { Dialog, DialogContent, DialogTrigger } from "./ui/dialog";
import { Badge } from "./ui/badge";

export function TaskDashboard() {
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [filter, setFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data: stats } = useQuery({
    queryKey: ['/api/tasks/stats'],
  });

  const { data: tasksData } = useQuery({
    queryKey: ['/api/tasks', filter],
    queryFn: () => fetch(`/api/tasks?status=${filter}`).then(res => res.json()),
  });

  const { data: suggestions } = useQuery({
    queryKey: ['/api/tasks/suggestions'],
  });

  const createTaskMutation = useMutation({
    mutationFn: (task: any) => 
      fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(task),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/stats'] });
      setShowCreateTask(false);
    },
  });

  const handleTaskCreated = (task: any) => {
    queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    queryClient.invalidateQueries({ queryKey: ['/api/tasks/stats'] });
    queryClient.invalidateQueries({ queryKey: ['/api/tasks/suggestions'] });
  };

  const statsData = stats as any;

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsData?.all || 0}</div>
            <p className="text-xs text-muted-foreground">
              +{statsData?.totalPoints || 0} points earned
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Due Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsData?.dueToday || 0}</div>
            <p className="text-xs text-muted-foreground">
              Focus needed
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsData?.completed || 0}</div>
            <p className="text-xs text-muted-foreground">
              Level {statsData?.level || 1}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Streak</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsData?.streakDays || 0}</div>
            <p className="text-xs text-muted-foreground">
              days in a row
            </p>
          </CardContent>
        </Card>
      </div>

      {/* AI Suggestions */}
      {suggestions && Array.isArray(suggestions) && suggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">AI Suggestions</CardTitle>
            <CardDescription>Based on your past tasks and patterns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {suggestions.slice(0, 3).map((suggestion: any) => (
                <div key={suggestion.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{suggestion.title}</p>
                    <p className="text-sm text-muted-foreground">{suggestion.description}</p>
                  </div>
                  <Button size="sm" onClick={() => {
                    // Create task from suggestion
                    createTaskMutation.mutate({
                      title: suggestion.title,
                      description: suggestion.description,
                      priority: suggestion.priority || 'medium',
                    });
                  }}>
                    Add Task
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <Tabs defaultValue="tasks" className="space-y-4">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="voice">Voice Assistant</TabsTrigger>
            <TabsTrigger value="gamification">Gamification</TabsTrigger>
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="habits">Habits</TabsTrigger>
          </TabsList>
          
          <div className="flex items-center gap-2">
            <Button
              variant={voiceEnabled ? "default" : "outline"}
              size="sm"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
            >
              {voiceEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
            </Button>
            <Dialog open={showCreateTask} onOpenChange={setShowCreateTask}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Task
                </Button>
              </DialogTrigger>
              <DialogContent>
                <TaskForm onSubmit={(data) => createTaskMutation.mutate(data)} />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex items-center gap-2">
            <Button
              variant={filter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter("all")}
            >
              All
            </Button>
            <Button
              variant={filter === "not_started" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter("not_started")}
            >
              To Do
            </Button>
            <Button
              variant={filter === "in_progress" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter("in_progress")}
            >
              In Progress
            </Button>
            <Button
              variant={filter === "completed" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter("completed")}
            >
              Completed
            </Button>
          </div>
          <TaskList tasks={tasksData?.tasks || []} filter={filter} voiceEnabled={voiceEnabled} />
        </TabsContent>

        <TabsContent value="voice">
          <VoiceAssistant onTaskCreated={handleTaskCreated} />
        </TabsContent>

        <TabsContent value="gamification">
          <Gamification />
        </TabsContent>

        <TabsContent value="calendar">
          <TaskCalendar />
        </TabsContent>

        <TabsContent value="analytics">
          <TaskAnalytics />
        </TabsContent>

        <TabsContent value="habits">
          <HabitTracker />
        </TabsContent>
      </Tabs>
    </div>
  );
}