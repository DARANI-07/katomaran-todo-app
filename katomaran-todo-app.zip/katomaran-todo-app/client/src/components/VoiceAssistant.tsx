import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Mic, MicOff, Send, Loader2, Mail, AlertTriangle } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '../hooks/use-toast';

interface VoiceAssistantProps {
  onTaskCreated?: (task: any) => void;
}

interface DueDateAlert {
  id: number;
  title: string;
  dueDate: string;
  dueDateText: string;
  priority: string;
  status: string;
  isUrgent: boolean;
}

export function VoiceAssistant({ onTaskCreated }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const recognitionRef = useRef<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check for due date alerts
  const { data: alerts } = useQuery<{ alerts: DueDateAlert[] }>({
    queryKey: ['/api/alerts/due-dates'],
    refetchInterval: 60000, // Check every minute
  });

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = '';
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        
        if (finalTranscript) {
          setTranscript(prev => (prev + ' ' + finalTranscript).trim());
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        
        // Only show error for actual errors, not expected states
        if (event.error !== 'aborted' && event.error !== 'no-speech') {
          toast({
            title: "Voice Recognition Error",
            description: `Speech recognition failed: ${event.error}. Please try again.`,
            variant: "destructive"
          });
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, [toast]);

  const processVoiceMutation = useMutation({
    mutationFn: async (data: { transcript: string; recipientEmail?: string }) => {
      const response = await fetch('/api/voice/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to process voice command');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Task Created Successfully!",
        description: `Created "${data.task.title}" ${data.emailSent ? 'and sent email notification' : ''}`,
      });
      setTranscript('');
      setRecipientEmail('');
      setShowEmailDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/stats'] });
      onTaskCreated?.(data.task);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create task from voice command",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsProcessing(false);
    }
  });

  const sendReminderMutation = useMutation({
    mutationFn: async (data: { taskId: number; recipientEmail: string }) => {
      const response = await fetch('/api/notifications/due-date-reminder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to send reminder');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Reminder Sent!",
        description: "Due date reminder email has been sent successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send reminder email",
        variant: "destructive"
      });
    }
  });

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true);
      setTranscript('');
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleSubmit = () => {
    if (!transcript.trim()) {
      toast({
        title: "No Voice Input",
        description: "Please record a voice command first",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    processVoiceMutation.mutate({
      transcript: transcript.trim(),
      recipientEmail: recipientEmail.trim() || undefined
    });
  };

  const handleSendReminder = (taskId: number) => {
    const email = prompt("Enter email address to send reminder:");
    if (email) {
      sendReminderMutation.mutate({ taskId, recipientEmail: email });
    }
  };

  const isSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;

  return (
    <div className="space-y-4">
      {/* Due Date Alerts */}
      {alerts?.alerts && alerts.alerts.length > 0 && (
        <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-orange-800 dark:text-orange-200">
              <AlertTriangle className="h-5 w-5" />
              Due Date Alerts
            </CardTitle>
            <CardDescription className="text-orange-700 dark:text-orange-300">
              You have {alerts.alerts.length} task(s) due soon
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.alerts.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">{alert.title}</h4>
                    <Badge variant={alert.isUrgent ? "destructive" : "secondary"}>
                      Due {alert.dueDateText}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {alert.priority}
                    </Badge>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleSendReminder(alert.id)}
                  disabled={sendReminderMutation.isPending}
                >
                  <Mail className="h-4 w-4 mr-1" />
                  Send Reminder
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Voice Assistant */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            AI Voice Assistant
          </CardTitle>
          <CardDescription>
            Create tasks using voice commands with AI-powered assistance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isSupported ? (
            <div className="text-center p-4 text-muted-foreground">
              Voice recognition is not supported in your browser
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2">
                <Button
                  onClick={isListening ? stopListening : startListening}
                  variant={isListening ? "destructive" : "default"}
                  disabled={isProcessing}
                  className={`flex-shrink-0 ${isListening ? 'voice-listening' : ''} transition-all duration-300`}
                >
                  {isListening ? (
                    <>
                      <MicOff className="h-4 w-4 mr-2" />
                      Stop Recording
                    </>
                  ) : (
                    <>
                      <Mic className="h-4 w-4 mr-2" />
                      Start Recording
                    </>
                  )}
                </Button>

                <Dialog open={showEmailDialog} onOpenChange={setShowEmailDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" disabled={!transcript.trim() || isProcessing}>
                      <Mail className="h-4 w-4 mr-2" />
                      Add Email
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Email Notification</DialogTitle>
                      <DialogDescription>
                        Enter an email address to notify when this task is created
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <input
                        type="email"
                        placeholder="recipient@example.com"
                        value={recipientEmail}
                        onChange={(e) => setRecipientEmail(e.target.value)}
                        className="w-full px-3 py-2 border rounded-md"
                      />
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setShowEmailDialog(false)}>
                          Cancel
                        </Button>
                        <Button onClick={() => setShowEmailDialog(false)}>
                          Save
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button
                  onClick={handleSubmit}
                  disabled={!transcript.trim() || isProcessing}
                  className="flex-shrink-0"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Create Task
                    </>
                  )}
                </Button>
              </div>

              {transcript && (
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium mb-1">Voice Input:</p>
                  <p className="text-sm">{transcript}</p>
                </div>
              )}

              {recipientEmail && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
                    Email Notification:
                  </p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">{recipientEmail}</p>
                </div>
              )}

              <div className="text-xs text-muted-foreground">
                💡 Try saying: "Create a high priority task to review the presentation due tomorrow" or "Add a meeting with John at 3 PM today"
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}