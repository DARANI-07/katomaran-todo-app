// Simple toast hook implementation
export function useToast() {
  return {
    toasts: [],
    toast: (message: any) => {
      console.log('Toast:', message);
    },
  };
}