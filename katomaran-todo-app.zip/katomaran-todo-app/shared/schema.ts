import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  boolean,
  date,
  integer,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date"),
  priority: varchar("priority", { enum: ["low", "medium", "high"] }).notNull().default("medium"),
  status: varchar("status", { enum: ["not_started", "in_progress", "completed"] }).notNull().default("not_started"),
  completed: boolean("completed").notNull().default(false),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  category: varchar("category").default("general"),
  tags: text("tags").array(),
  estimatedTime: integer("estimated_time"), // in minutes
  actualTime: integer("actual_time"), // in minutes
  reminderTime: timestamp("reminder_time"),
  isRecurring: boolean("is_recurring").default(false),
  recurringPattern: varchar("recurring_pattern"), // daily, weekly, monthly
  moodRequired: varchar("mood_required", { enum: ["any", "focused", "creative", "energetic", "calm"] }).default("any"),
  gamificationPoints: integer("gamification_points").default(0),
  difficulty: integer("difficulty").default(1), // 1-5 scale
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Task shares table for sharing functionality
export const taskShares = pgTable("task_shares", {
  id: serial("id").primaryKey(),
  taskId: serial("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  sharedWithEmail: varchar("shared_with_email").notNull(),
  sharedByUserId: varchar("shared_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow(),
});

// User preferences table
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  theme: varchar("theme").default("light"), // light, dark, custom
  primaryColor: varchar("primary_color").default("#3b82f6"),
  accentColor: varchar("accent_color").default("#10b981"),
  isMinimalMode: boolean("is_minimal_mode").default(false),
  gamificationEnabled: boolean("gamification_enabled").default(true),
  voiceControlEnabled: boolean("voice_control_enabled").default(false),
  notificationsEnabled: boolean("notifications_enabled").default(true),
  reminderTime: integer("reminder_time").default(30), // minutes before due date
  currentMood: varchar("current_mood", { enum: ["focused", "creative", "energetic", "calm"] }).default("focused"),
  totalPoints: integer("total_points").default(0),
  level: integer("level").default(1),
  streakDays: integer("streak_days").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Habits table
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  frequency: varchar("frequency", { enum: ["daily", "weekly", "monthly"] }).notNull(),
  targetCount: integer("target_count").default(1),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
  isActive: boolean("is_active").default(true),
  category: varchar("category").default("general"),
  points: integer("points").default(5),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Habit logs table
export const habitLogs = pgTable("habit_logs", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id, { onDelete: "cascade" }),
  completedAt: timestamp("completed_at").defaultNow(),
  notes: text("notes"),
});

// Task completion analytics
export const taskAnalytics = pgTable("task_analytics", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: date("date").notNull(),
  tasksCompleted: integer("tasks_completed").default(0),
  tasksCreated: integer("tasks_created").default(0),
  pointsEarned: integer("points_earned").default(0),
  averageCompletionTime: real("average_completion_time"), // in minutes
  productivityScore: real("productivity_score").default(0), // 0-100
  moodRating: integer("mood_rating"), // 1-5
});

// Task suggestions
export const taskSuggestions = pgTable("task_suggestions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  suggestedTitle: text("suggested_title").notNull(),
  suggestedDescription: text("suggested_description"),
  suggestedPriority: varchar("suggested_priority", { enum: ["low", "medium", "high"] }).default("medium"),
  suggestedCategory: varchar("suggested_category").default("general"),
  basedOnPattern: text("based_on_pattern"), // explanation of why suggested
  isAccepted: boolean("is_accepted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { enum: ["reminder", "due_date", "achievement", "suggestion"] }).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  taskId: integer("task_id").references(() => tasks.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  tasks: many(tasks),
  sharedTasks: many(taskShares),
  preferences: one(userPreferences),
  habits: many(habits),
  analytics: many(taskAnalytics),
  suggestions: many(taskSuggestions),
  notifications: many(notifications),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  user: one(users, {
    fields: [tasks.userId],
    references: [users.id],
  }),
  shares: many(taskShares),
  notifications: many(notifications),
}));

export const taskSharesRelations = relations(taskShares, ({ one }) => ({
  task: one(tasks, {
    fields: [taskShares.taskId],
    references: [tasks.id],
  }),
  sharedBy: one(users, {
    fields: [taskShares.sharedByUserId],
    references: [users.id],
  }),
}));

export const userPreferencesRelations = relations(userPreferences, ({ one }) => ({
  user: one(users, {
    fields: [userPreferences.userId],
    references: [users.id],
  }),
}));

export const habitsRelations = relations(habits, ({ one, many }) => ({
  user: one(users, {
    fields: [habits.userId],
    references: [users.id],
  }),
  logs: many(habitLogs),
}));

export const habitLogsRelations = relations(habitLogs, ({ one }) => ({
  habit: one(habits, {
    fields: [habitLogs.habitId],
    references: [habits.id],
  }),
}));

export const taskAnalyticsRelations = relations(taskAnalytics, ({ one }) => ({
  user: one(users, {
    fields: [taskAnalytics.userId],
    references: [users.id],
  }),
}));

export const taskSuggestionsRelations = relations(taskSuggestions, ({ one }) => ({
  user: one(users, {
    fields: [taskSuggestions.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  task: one(tasks, {
    fields: [notifications.taskId],
    references: [tasks.id],
  }),
}));

// Schemas
export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const updateTaskSchema = insertTaskSchema.partial();

export const insertTaskShareSchema = createInsertSchema(taskShares).omit({
  id: true,
  sharedByUserId: true,
  createdAt: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const updateUserPreferencesSchema = insertUserPreferencesSchema.partial();

export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const updateHabitSchema = insertHabitSchema.partial();

export const insertHabitLogSchema = createInsertSchema(habitLogs).omit({
  id: true,
  completedAt: true,
});

export const insertTaskAnalyticsSchema = createInsertSchema(taskAnalytics).omit({
  id: true,
  userId: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  userId: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type UpdateTask = z.infer<typeof updateTaskSchema>;
export type TaskShare = typeof taskShares.$inferSelect;
export type InsertTaskShare = z.infer<typeof insertTaskShareSchema>;

export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UpdateUserPreferences = z.infer<typeof updateUserPreferencesSchema>;

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type UpdateHabit = z.infer<typeof updateHabitSchema>;

export type HabitLog = typeof habitLogs.$inferSelect;
export type InsertHabitLog = z.infer<typeof insertHabitLogSchema>;

export type TaskAnalytics = typeof taskAnalytics.$inferSelect;
export type InsertTaskAnalytics = z.infer<typeof insertTaskAnalyticsSchema>;

export type TaskSuggestion = typeof taskSuggestions.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
